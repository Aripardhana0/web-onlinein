globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7608c2e0f67d3200.js",
    "static/chunks/7ebaf881f5fa7446.js",
    "static/chunks/46555f69f67186d0.js",
    "static/chunks/f8a37bf13cb7bc72.js",
    "static/chunks/turbopack-7dc1fc4595b5d189.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];