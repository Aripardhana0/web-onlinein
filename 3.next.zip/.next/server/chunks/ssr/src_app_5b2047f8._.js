module.exports=[10585,a=>{a.v("/_next/static/media/favicon.729ed23c.ico")},68611,a=>{"use strict";let b={src:a.i(10585).default,width:1024,height:1024};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_5b2047f8._.js.map